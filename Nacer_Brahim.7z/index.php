<?php

error_reporting(-1);
ini_set('display_errors', 'On');



require_once '../Nacer_Brahim/bootstrap.php';

// Init Core Library
$init = new Core();
